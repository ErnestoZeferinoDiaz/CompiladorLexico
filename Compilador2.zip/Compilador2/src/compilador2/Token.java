
package compilador2;

public interface Token {
    public String getValue();
    //public Constant getConstant();
    
}
